package com.example.spring_jwt.service;

import com.example.spring_jwt.entity.User;
import com.example.spring_jwt.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;
//
//    public List<User> allUsers() {
//       return (List<User>) userRepo.findAll();
//    }

    public List<User> allUsers() {
        List<User> users = new ArrayList<>();

        userRepo.findAll().forEach(users::add);

        return users;
    }

}
