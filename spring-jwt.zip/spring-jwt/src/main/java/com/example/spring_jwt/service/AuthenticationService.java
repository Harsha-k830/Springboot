package com.example.spring_jwt.service;

import com.example.spring_jwt.DTO.LoginUserDTO;
import com.example.spring_jwt.DTO.RegistrationUserDTO;
import com.example.spring_jwt.entity.User;
import com.example.spring_jwt.repository.UserRepo;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {

    private final UserRepo userRepository;

    private final PasswordEncoder passwordEncoder;

    private final AuthenticationManager authenticationManager;

    public AuthenticationService(
            UserRepo userRepository,
            AuthenticationManager authenticationManager,
            PasswordEncoder passwordEncoder
    ) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }


    public User signUp(RegistrationUserDTO registrationUserDTO){
        User user = new User();
        user.setFullName(registrationUserDTO.getFullName());
        user.setPassword(passwordEncoder.encode(registrationUserDTO.getPassword()));
        user.setEmail(registrationUserDTO.getEmail());
        return userRepository.save(user);
    }

    public User authenticate(LoginUserDTO input) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        input.getEmail(),
                        input.getPassword()
                )
        );

        return userRepository.findByEmail(input.getEmail())
                .orElseThrow();
    }
}
